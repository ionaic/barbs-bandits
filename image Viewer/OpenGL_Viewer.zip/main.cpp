#include "libs.h"
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "shader.h"
using std::cout; using std::endl;

// global variables to store the scene geometry
GLuint vertexArrayID;
GLuint bufferIDs[2];
// GL texture ID
GLuint TexID = 0;
// shader program
Shader shader;

// initialize the scene geometry
void initGeometry() {
	static const GLfloat rawVertexData[12] = { -1.0f,1.0f,0.0f, -1.0f,-1.0f,0.0f,  1.0f,1.0f,0.0f,  1.0f,-1.0f,0.0f };
	static const GLfloat rawTexCoordData[12] = {0.0f,1.0f,0.0f,  0.0f, 0.0f,0.0f,  1.0f,1.0f,0.0f,  1.0f,0.0f,0.0f };
	// create a new renderable object and set it to be active
	glGenVertexArrays(1,&vertexArrayID);
	glBindVertexArray(vertexArrayID);
	// create buffers for associated data
	glGenBuffers(2,bufferIDs);
	
	// set a buffer to be active and shove vertex data into it
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[0]);
	glBufferData(GL_ARRAY_BUFFER, 12*sizeof(GLfloat), rawVertexData, GL_STATIC_DRAW);
	// bind that data to shader variable 0
	glVertexAttribPointer((GLuint)0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);
	
	// set a buffer to be active and shove color data into it
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[1]);
	glBufferData(GL_ARRAY_BUFFER, 12*sizeof(GLfloat), rawTexCoordData, GL_STATIC_DRAW);
	// bind that data to shader variable 1
	glVertexAttribPointer((GLuint)1, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);
}
void bindShaderAttribLocations(GLuint p) {
	// assign numerical IDs to the variables that we pass to the shaders 
	glBindAttribLocation(p,0, "in_Position");
	glBindAttribLocation(p,1, "in_ColorTexCoords");
}
void initShaders() {
	shader = Shader(ShaderCallbacks(bindShaderAttribLocations));
	if (!shader.loadShaderFiles("textured.vert","textured.frag")) {
		shader.getErrortext(cout);
		exit(1);
	}
	shader.bind();
	glUniform1i(glGetUniformLocation(shader.id(),"ColorTex"), 0);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D,TexID);
}

// Callback for when the window is resized
void GLFWCALL windowResize( int width, int height ) {
	glViewport(0,0,(GLsizei)width,(GLsizei)height);
}
void HandleDevILErrors () {
	ILenum error = ilGetError ();
	if (error != IL_NO_ERROR) {
		do {
			printf ("\n\n%s\n", iluErrorString (error));	
		} while ((error = ilGetError ()));
		exit (1);
	}
}
int main( int argc, char ** argv ) {
	if (argc<2) {
		cout << "Please pass the path to an image file as a parameter to the program!\n";
		exit(1);
	}
	// init DevIL
	if (ilGetInteger(IL_VERSION_NUM) < IL_VERSION ||
		iluGetInteger(ILU_VERSION_NUM) < ILU_VERSION ||
		ilutGetInteger(ILUT_VERSION_NUM) < ILUT_VERSION) {
		cout << "DevIL library is out of date! Please upgrade"<<endl;
		return 2;
	}
	// Needed to initialize DevIL.
	ilInit ();
	iluInit();
	// GL cannot use palettes anyway, so convert early.
	ilEnable (IL_CONV_PAL);
	// Gets rid of dithering on some nVidia-based cards.
	ilutEnable (ILUT_OPENGL_CONV);
	
	// Initialize GLFW
	if( !glfwInit() ) {
		exit( EXIT_FAILURE );
	}
	// Open an OpenGL window
	if( !glfwOpenWindow( 800,600, 0,0,0,0,0,0, GLFW_WINDOW ) ) {
		glfwTerminate();
		exit( EXIT_FAILURE );
	}
	
	glfwSetWindowTitle("OpenGL Viewer");
	glfwSetWindowSizeCallback( windowResize );
	glfwSwapInterval( 1 );
	windowResize(800,600);
	glewInit();
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	// load a texture
	{
		// IL image ID
		ILuint ImgId = 0;
		
		// Generate the main image name to use.
		ilGenImages (1, &ImgId);
		
		// Bind this image name.
		ilBindImage (ImgId);

		// Loads the image specified by File into the ImgId image.
		if (!ilLoadImage (argv[1])) {
			HandleDevILErrors ();
		}
		glEnable(GL_TEXTURE_2D);
		// Lets ILUT know to use its OpenGL functions.
		ilutRenderer (ILUT_OPENGL);
		// Goes through all steps of sending the image to OpenGL.
		TexID = ilutGLBindTexImage();
		// We're done with our image, so we go ahead and delete it.
		ilDeleteImages(1, &ImgId);
	}
	ilShutDown();
	// last of the init
	initGeometry();
	initShaders();
	GLint texUnits;
	glGetIntegerv(GL_MAX_TEXTURE_UNITS,&texUnits);
	cout << "# of tex units: " << texUnits << endl;
	// Main loop
	int running = GL_TRUE;
	while( running ) {
		// OpenGL rendering goes here...
		glClear( GL_COLOR_BUFFER_BIT );
		// draw the triangle
		glBindVertexArray(vertexArrayID);
		glDrawArrays(GL_TRIANGLE_STRIP,0,4);
		// Swap front and back rendering buffers
		glfwSwapBuffers();
		// Check if ESC key was pressed or window was closed
		running = !glfwGetKey( GLFW_KEY_ESC ) && glfwGetWindowParam( GLFW_OPENED );
	}
	// delete the texture
	glDeleteTextures(1, &TexID);
	// delete the buffers
	glDeleteVertexArrays(1,&vertexArrayID);
	glDeleteBuffers(3,bufferIDs);
	// Close window and terminate GLFW
	glfwTerminate();
	// Exit program
	exit( EXIT_SUCCESS );
}
