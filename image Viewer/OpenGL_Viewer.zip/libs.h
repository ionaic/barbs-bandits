#ifndef __libs_h__
#define __libs_h__

#include <GL/glew.h>
#include <GL/glfw.h>
#define ILUT_USE_OPENGL
#include <IL/il.h>
#include <IL/ilu.h>
#include <IL/ilut.h>

#endif
